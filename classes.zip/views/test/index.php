Test view <br/>

<table>
    <? foreach ($tasks as $item) {
        ?>

    <?
    }
    ?>
</table>
